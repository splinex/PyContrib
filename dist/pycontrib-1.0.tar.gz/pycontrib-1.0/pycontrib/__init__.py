# import sys
# import os
# import importlib

# if 'tornado' in sys.modules:
#     raise BaseException('Tornado was imported')
#
# sys.path.insert(0, os.path.dirname(__file__))
